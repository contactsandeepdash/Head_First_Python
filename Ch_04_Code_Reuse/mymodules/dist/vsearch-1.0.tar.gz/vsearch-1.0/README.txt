Head First Python
---------------------------------
Search vowels in a phrase